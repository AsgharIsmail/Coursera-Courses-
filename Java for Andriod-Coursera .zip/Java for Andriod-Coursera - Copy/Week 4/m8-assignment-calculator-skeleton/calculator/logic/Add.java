package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
    // TODO -- start your code here
    private int mArgumentOne = 0;
    private int mArgumentTwo = 0;

    public Add(int argumentOne, int argumentTwo) { // Taking two parameters in constructor

        mArgumentOne = argumentOne;    // Setting both arguments to constructor parameter
        mArgumentTwo = argumentTwo;
    }

    public String toString() {                   // method to return string
        return String.valueOf(mArgumentOne + mArgumentTwo);  // addition operation here
    }
}
