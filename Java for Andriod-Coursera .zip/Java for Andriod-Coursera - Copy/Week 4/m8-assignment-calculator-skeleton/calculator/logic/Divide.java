package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide {
    // TODO -- start your code here
    private int mArgumentOne = 0;
    private int mArgumentTwo = 0;
    private String result;

    public Divide(int argumentOne, int argumentTwo) {         // Taking two parameters in constructor

        mArgumentOne = argumentOne;                          // Setting both arguments to constructor parameter
        mArgumentTwo = argumentTwo;
        try{
          // doing division operation here and converting integer value of division and reminder to string value
          String result = String.valueOf(mArgumentOne / mArgumentTwo) + " R:" + String.valueOf(mArgumentOne % mArgumentTwo);

        }catch(ArithmeticException e){
            result = "Math Error! Division by zero is not allowed.";   // try catch exception handling for division by zero
        }
    }
    public String toString() {    // method to return string
        return  result;
    }
}
